<?php
//编辑器组件

global $_GPC;
$className=$_GPC['rand_class'];
include $this->template("editor");