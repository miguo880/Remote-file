<?php
//选择处理人员组

global $_GPC;
include $this->template("select_user");